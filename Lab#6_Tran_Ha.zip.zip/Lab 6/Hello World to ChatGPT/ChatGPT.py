import os
import openai
from dotenv import load_dotenv

load_dotenv()

# Set the API key from the environment variable
openai.api_key = ("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")

# Define the function to generate the OpenAI response
def generate_response(prompt):
    model_engine = "text-davinci-002"
    prompt = f"{prompt}"

    completions = openai.Completion.create(
        engine=model_engine,
        prompt=prompt,
        max_tokens=1024,
        n=1,
        stop="###",
        temperature=0.5,
    )

    message = completions.choices[0].text
    return message.strip()

# Loop to take user input and generate OpenAI response
def main():
    print("Welcome to ChatGPT! Type 'quit' to exit.\n")

    while True:
        # Prompt user for input
        prompt = input("You: ")

        # Exit loop if user enters 'quit'
        if prompt == "quit":
            break

        # Generate response from OpenAI and display it
        response = generate_response(prompt)
        print("ChatGPT: " + response)

    print("\nGoodbye!")

if __name__ == "__main__":
    main()
